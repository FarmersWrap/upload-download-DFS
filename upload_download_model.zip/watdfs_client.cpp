//
// Starter code for CS 454/654
// You SHOULD change this file
//
// #include "fuse.h"
#include "watdfs_client.h"
#include "debug.h"
INIT_LOG

#include "rpc.h"
#include <ctime>
#include <sys/stat.h>
#include <set>
#include <map>
#include "rw_lock.h"

using namespace std;

struct FileInfo {
    time_t tc;
    int flags;
    int client_file_desc;
    int server_file_desc;
};

struct UserData {
    // Store the FileInfo into a map with path as the key
    map<string, FileInfo *> file_info;
    // maintain a set recording the opened files
    set<string> file_set;
    time_t cache_interval;
    char *path_to_cache;
};

int lock(const char *path, rw_lock_mode_t mode);
int unlock(const char *path, rw_lock_mode_t mode);

// GET FILE ATTRIBUTES
int watdfs_cli_getattr_a1(void *userdata, const char *path, struct stat *statbuf);

// CREATE, OPEN AND CLOSE
int watdfs_cli_mknod_a1(void *userdata, const char *path, mode_t mode, dev_t dev);
int watdfs_cli_open_a1(void *userdata, const char *path,
                    struct fuse_file_info *fi);
int watdfs_cli_release_a1(void *userdata, const char *path,
                       struct fuse_file_info *fi);

// READ AND WRITE DATA
int watdfs_cli_read_a1(void *userdata, const char *path, char *buf, size_t size,
                    off_t offset, struct fuse_file_info *fi);
int watdfs_cli_write_a1(void *userdata, const char *path, const char *buf,
                     size_t size, off_t offset, struct fuse_file_info *fi);
int watdfs_cli_truncate_a1(void *userdata, const char *path, off_t newsize);

// CHANGE METADATA
int watdfs_cli_utimens_a1(void *userdata, const char *path,
                       const struct timespec ts[2]);

// We need to operate on the path relative to the the cleint_persist_dir.
// This function returns a path that appends the given short path to the
// cleint_persist_dir. The character array is allocated on the heap, therefore
// it should be freed after use.
// Tip: update this function to return a unique_ptr for automatic memory management.
char *get_full_path(char *cleint_persist_dir, const char *short_path) {
    int short_path_len = strlen(short_path);
    int dir_len = strlen(cleint_persist_dir);
    int full_len = dir_len + short_path_len + 1;

    char *fp = (char *)malloc(full_len);

    // First fill in the directory.
    strcpy(fp, cleint_persist_dir);
    // Then append the path.
    strcat(fp, short_path);
    DLOG("Full path: %s\n", fp);

    return fp;
}

/* download(Userdata *userdata, const char *path, fuse_file_info *i) is used to 
download the file from server to the client.Firstly, the function uses the method we 
implemented in a1 watdfs_cli_getattr_a1 to retreive the stat of the file on the server, 
and store the information in the variable stat buffer. Then, we use the method 
watdfs_cli_open_a1 to open the file on the server. If succeed, we add the file 
information(file handler) to the our UserData data structure. After recording the server 
information, we open or create a local file and truncate the local file the same as the 
server file. The information is in the stat buffer. Now, we have to lock the file in 
RW_READ_LOCK mode, and then read the file using watdfs_cli_read_a1 from server, unlock the file. 
If reading succeeds, the read file is in the local buffer on the client machine. We move the 
file from memory to disk using pwrite. Finally, we have to update the metadata
(statbuf.st_atim and statbuf.st_mtim) of the local file using utimensat.
*/
int download(UserData *userdata, const char *path, struct fuse_file_info *fi) {
    char *fp = get_full_path(userdata->path_to_cache, path);
    struct stat statbuf;
    // get the stat from the seerver
    int fxn_ret = watdfs_cli_getattr_a1(userdata, path, &statbuf);
    if (fxn_ret < 0) {
        free(fp);
        return fxn_ret;
    }
    int client_file_desc = 0;
    off_t fsz = statbuf.st_size;
    fxn_ret = watdfs_cli_open_a1(userdata, path, fi);
    if (fxn_ret < 0) return fxn_ret;
    // Create a new FileInfo
    if (userdata->file_info.count(path) == 0) userdata->file_info[path] = new struct FileInfo;
    // set the file handler
    userdata->file_info[path]->server_file_desc = fi->fh;
    int return_file = open(fp, O_RDWR | O_CREAT, S_IRWXU);
    if (return_file < 0) {
        free(fp);
        return -errno;
    }
    client_file_desc = return_file;
    userdata->file_info[path]->client_file_desc = client_file_desc;
    // truncate the file to the same size
    fxn_ret = truncate(fp, fsz);
    if (fxn_ret < 0) {
        free(fp);
        return -errno;
    }
    char *buf = (char *)malloc((fsz + 1) * sizeof(char));
    fxn_ret = lock(path, RW_READ_LOCK);
    if (fxn_ret < 0) {
        free(fp);
        free(buf);
        return fxn_ret;
    }
    // read from the server
    fxn_ret = watdfs_cli_read_a1(userdata, path, buf, fsz, 0, fi);
    if (fxn_ret < 0) {
        free(fp);
        free(buf);
        unlock(path, RW_READ_LOCK);
        return fxn_ret;
    }
    // unlock the file
    fxn_ret = unlock(path, RW_READ_LOCK);
    if (fxn_ret < 0) {
        free(fp);
        free(buf);
        return fxn_ret;
    }
    // write to disk
    fxn_ret = pwrite(client_file_desc, buf, fsz, 0);
    if (fxn_ret < 0) {
        free(fp);
        free(buf);
        return fxn_ret;
    }

    struct timespec *ts = new struct timespec[2];
    ts[0] = statbuf.st_atim;
    ts[1] = statbuf.st_mtim;
    // update the metadata on the local file
    fxn_ret = utimensat(0, fp, ts, 0);
    free(fp);
    free(buf);
    return fxn_ret;
}


/*The function upload(Userdata *userdata, const char *path, fuse_file_info *i)
 is used to upload a file from the client to the server.
 Firstly, the function uses stat to retreive the local file stats, and store the
 file information in a stat buffer. Then, the client move the file from disk to 
 memory buffer, and lock the file in RW_WRITE_LOCK mode. The client uses the method 
 we implemented in a1 watdfs_cli_truncate_a1 to truncate the file on the server to 
 the same size as it is on the client, and write the information in the buffer to 
 the server machine using watdfs_cli_write_a1. We have to update the 
 metadata(statbuf.st_atim and statbuf.st_mtim) of the server file using 
 watdfs_cli_utimens_a1. Finally, we unlock the file.
*/
int upload(UserData *userdata, const char *path, struct fuse_file_info *fi) {
    char *fp = get_full_path(userdata->path_to_cache, path);
    struct stat statbuf;
    // get the file stat on the local machine
    int fxn_ret = stat(fp, &statbuf);
    if (fxn_ret < 0) {
        free(fp);
        return -errno;
    }
    off_t fsz = statbuf.st_size;
    char *buf = (char *)malloc(fsz * sizeof(char));
    int client_file_desc = userdata->file_info[path]->client_file_desc;
    // read from disk to mem
    fxn_ret = pread(client_file_desc, buf, fsz, 0);
    if (fxn_ret < 0) {
        free(fp);
        free(buf);
        return -errno;
    }
    // lock the file
    fxn_ret = lock(path, RW_WRITE_LOCK);
    if (fxn_ret < 0) {
        free(fp);
        free(buf);
        return fxn_ret;
    }
    // truncate the file on the server to the same size as it on the client
    fxn_ret = watdfs_cli_truncate_a1(userdata, path, fsz);
    if (fxn_ret < 0) {
        unlock(path, RW_WRITE_LOCK);
        free(fp);
        free(buf);
        return fxn_ret;
    }
    // write to the server file
    fxn_ret = watdfs_cli_write_a1(userdata, path, buf, fsz, 0, fi);
    if (fxn_ret < 0) {
        unlock(path, RW_WRITE_LOCK);
        free(fp);
        free(buf);
        return fxn_ret;
    }
    // We want to update the metadata
    struct timespec *ts = new struct timespec[2];
    ts[0] = statbuf.st_atim;
    ts[1] = statbuf.st_mtim;
    // update
    fxn_ret = watdfs_cli_utimens_a1(userdata, path, ts);
    unlock(path, RW_WRITE_LOCK);
    free(fp);
    free(buf);
    delete[] ts;
    return fxn_ret;
}

int watdfs_cli_read_check(UserData *userdata, const char *path) {
    // time at client
    time_t Tc = userdata->file_info[path]->tc;
    // current time
    time_t T = time(nullptr);
    // time interval
    time_t t = userdata->cache_interval;
    if (T - Tc < t) return 0;
    char *fp = get_full_path(userdata->path_to_cache, path);
    struct stat statbuf;
    int fxn_ret = stat(fp, &statbuf);
    if (fxn_ret < 0) return -errno;
    // record the client time
    time_t T_client = statbuf.st_mtime;
    // get stat on the serverfile
    fxn_ret = watdfs_cli_getattr_a1(userdata, path, &statbuf);
    if (fxn_ret < 0) return fxn_ret;
    // record the server time
    time_t T_server = statbuf.st_mtime;
    // if the time is the same
    if (T_client == T_server) {
        userdata->file_info[path]->tc = time(nullptr);
        return 0;
    }
    struct fuse_file_info fi;
    fi.flags = O_RDONLY;
    fi.fh = userdata->file_info[path]->server_file_desc;
    // download from the server
    fxn_ret = download(userdata, path, &fi);
    userdata->file_info[path]->tc = time(nullptr);
    return fxn_ret;

}

int watdfs_cli_write_check(UserData *userdata, const char *path) {
    // time at client
    time_t Tc = userdata->file_info[path]->tc;
    // current time
    time_t T = time(nullptr);
    // time interval
    time_t t = userdata->cache_interval;
    // check time
    if (T - Tc < t) return 0;
    char *fp = get_full_path(userdata->path_to_cache, path);
    struct stat statbuf;
    int fxn_ret = stat(fp, &statbuf);
    if (fxn_ret < 0) return -errno;
    // read from stat
    time_t T_client = statbuf.st_mtime;
    // updata the stat from server
    fxn_ret = watdfs_cli_getattr_a1(userdata, path, &statbuf);
    if (fxn_ret < 0) return fxn_ret;
    // read from stat
    time_t T_server = statbuf.st_mtime;
    // check time
    if (T_client == T_server) {
        userdata->file_info[path]->tc = time(nullptr);
        return 0;
    }
    fuse_file_info fi;
    fi.flags = O_RDWR;
    fi.fh = userdata->file_info[path]->server_file_desc;
    // Diff from read check
    // we upload the file
    fxn_ret = upload(userdata, path, &fi);
    userdata->file_info[path]->tc = time(nullptr);
    return fxn_ret;
}



// SETUP AND TEARDOWN
void *watdfs_cli_init(struct fuse_conn_info *conn, const char *path_to_cache,
                      time_t cache_interval, int *ret_code) {
    // TODO: set up the RPC library by calling `rpcClientInit`.
    int err = rpcClientInit();
    // TODO: check the return code of the `rpcClientInit` call
    // `rpcClientInit` may fail, for example, if an incorrect port was exported.

    if (err >= 0) *ret_code = 0;
    // It may be useful to print to stderr or stdout during debugging.
    // Important: Make sure you turn off logging prior to submission!
    // One useful technique is to use pre-processor flags like:
    // # ifdef PRINT_ERR
    // std::cerr << "Failed to initialize RPC Client" << std::endl;
    // #endif
    // Tip: Try using a macro for the above to minimize the debugging code.

    // TODO Initialize any global state that you require for the assignment and return it.
    // The value that you return here will be passed as userdata in other functions.
    // In A1, you might not need it, so you can return `nullptr`.
    UserData *userdata = new UserData;


    // TODO: save `path_to_cache` and `cache_interval` (for A3).
    userdata->path_to_cache = (char *) malloc(strlen(path_to_cache) + 1);
    strcpy(userdata->path_to_cache, path_to_cache);
    userdata->cache_interval = cache_interval;

    // TODO: set `ret_code` to 0 if everything above succeeded else some appropriate
    // non-zero value.
    *ret_code = 0;
    // Return pointer to global state data.
    return (void *) userdata;
}

void watdfs_cli_destroy(void *userdata) {
    // TODO: clean up your userdata state.
    free(((UserData *)userdata)->path_to_cache);
    free((UserData *)userdata);
    // TODO: tear down the RPC library by calling `rpcClientDestroy`.
    rpcClientDestroy();
}

// GET FILE ATTRIBUTES
int watdfs_cli_getattr_a1(void *userdata, const char *path, struct stat *statbuf) {
    // SET UP THE RPC CALL
    DLOG("watdfs_cli_getattr called for '%s'", path);
    
    // getattr has 3 arguments.
    int ARG_COUNT = 3;

    // Allocate space for the output arguments.
    void **args = new void*[ARG_COUNT];

    // Allocate the space for arg types, and one extra space for the null
    // array element.
    int arg_types[ARG_COUNT + 1];

    // The path has string length (strlen) + 1 (for the null character).
    int pathlen = strlen(path) + 1;

    // Fill in the arguments
    // The first argument is the path, it is an input only argument, and a char
    // array. The length of the array is the length of the path.
    arg_types[0] =
        (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) pathlen;
    // For arrays the argument is the array pointer, not a pointer to a pointer.
    args[0] = (void *)path;

    // The second argument is the stat structure. This argument is an output
    // only argument, and we treat it as a char array. The length of the array
    // is the size of the stat structure, which we can determine with sizeof.
    arg_types[1] = (1u << ARG_OUTPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) |
                   (uint) sizeof(struct stat); // statbuf
    args[1] = (void *)statbuf;

    // The third argument is the return code, an output only argument, which is
    // an integer.
    // TODO: fill in this argument type.

    arg_types[2] = ((1u << ARG_OUTPUT) | (ARG_INT << 16u));


    // The return code is not an array, so we need to hand args[2] an int*.
    // The int* could be the address of an integer located on the stack, or use
    // a heap allocated integer, in which case it should be freed.
    // TODO: Fill in the argument

    int return_code = 0;
    args[2] = &return_code;

    // Finally, the last position of the arg types is 0. There is no
    // corresponding arg.
    arg_types[3] = 0;

    // MAKE THE RPC CALL
    int rpc_ret = rpcCall((char *)"getattr", arg_types, args);

    // HANDLE THE RETURN
    // The integer value watdfs_cli_getattr will return.
    int fxn_ret = 0;
    if (rpc_ret < 0) {
        DLOG("getattr rpc failed with error '%d'", rpc_ret);
        // Something went wrong with the rpcCall, return a sensible return
        // value. In this case lets return, -EINVAL
        fxn_ret = -EINVAL;
    } else {
        // Our RPC call succeeded. However, it's possible that the return code
        // from the server is not 0, that is it may be -errno. Therefore, we
        // should set our function return value to the retcode from the server.

        // TODO: set the function return value to the return code from the server.
        if (return_code < 0) fxn_ret = return_code;
    }

    if (fxn_ret < 0) {
        // If the return code of watdfs_cli_getattr is negative (an error), then 
        // we need to make sure that the stat structure is filled with 0s. Otherwise,
        // FUSE will be confused by the contradicting return values.
        memset(statbuf, 0, sizeof(struct stat));
    }

    // Clean up the memory we have allocated.
    delete []args;

    // Finally return the value we got from the server.
    return fxn_ret;
}

// CREATE, OPEN AND CLOSE
int watdfs_cli_mknod_a1(void *userdata, const char *path, mode_t mode, dev_t dev) {
    // Called to create a file.
    DLOG("watdfs_cli_mknod called for '%s'", path);
    // SET UP THE RPC CALL    
    // mknod has 4 arguments.
    int ARG_COUNT = 4;

    // Allocate space for the output arguments.
    void **args = new void*[ARG_COUNT];

    // Allocate the space for arg types, and one extra space for the null
    // array element.
    int arg_types[ARG_COUNT + 1];

    // The path has string length (strlen) + 1 (for the null character).
    int pathlen = strlen(path) + 1;

    // Fill in the arguments
    // The first argument is the path, it is an input only argument, and a char
    // array. The length of the array is the length of the path.
    arg_types[0] =
        (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) pathlen;
    // For arrays the argument is the array pointer, not a pointer to a pointer.
    args[0] = (void *)path;

    // The second argument is mode.
    arg_types[1] = (1u << ARG_INPUT) | (ARG_INT << 16u);
    args[1] = &mode;

    // The third argument is dev
    arg_types[2] = ((1u << ARG_INPUT) | (ARG_LONG << 16u));
    args[2] = &dev;

    // The forth argument is the return code, an output only argument, which is
    // an integer.
    arg_types[3] = (1u << ARG_OUTPUT) | (ARG_INT << 16u);
    int return_code = 0;
    args[3] = &return_code;

    // Finally, the last position of the arg types is 0. There is no
    // corresponding arg.
    arg_types[4] = 0;

    // MAKE THE RPC CALL
    int rpc_ret = rpcCall((char *)"mknod", arg_types, args);

    // HANDLE THE RETURN
    // The integer value watdfs_cli_mknod will return.
    int fxn_ret = 0;
    if (rpc_ret < 0) {
        DLOG("mknod rpc failed with error '%d'", rpc_ret);
        // Something went wrong with the rpcCall, return a sensible return
        // value. In this case lets return, -EINVAL
        fxn_ret = -EINVAL;
    } else {
        // Our RPC call succeeded. However, it's possible that the return code
        // from the server is not 0, that is it may be -errno. Therefore, we
        // should set our function return value to the retcode from the server.
        // TODO: set the function return value to the return code from the server.
        if (return_code < 0) fxn_ret = return_code;
    }
    // Clean up the memory we have allocated.
    delete []args;
    // Finally return the value we got from the server.
    return fxn_ret;
}

int watdfs_cli_open_a1(void *userdata, const char *path,
                    struct fuse_file_info *fi) {
    // Called during open.
    // You should fill in fi->fh.
        // Called to create a file.
    DLOG("watdfs_cli_open called for '%s'", path);
    // SET UP THE RPC CALL    
    // open has 3 arguments.
    int ARG_COUNT = 3;

    // Allocate space for the output arguments.
    void **args = new void*[ARG_COUNT];

    // Allocate the space for arg types, and one extra space for the null
    // array element.
    int arg_types[ARG_COUNT + 1];

    // The path has string length (strlen) + 1 (for the null character).
    int pathlen = strlen(path) + 1;

    // Fill in the arguments
    // The first argument is the path, it is an input only argument, and a char
    // array. The length of the array is the length of the path.
    arg_types[0] =
        (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) pathlen;
    // For arrays the argument is the array pointer, not a pointer to a pointer.
    args[0] = (void *)path;

    // The second argument is fi.
    arg_types[1] = (1u << ARG_INPUT) | (1u << ARG_OUTPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint)sizeof(fuse_file_info);
    args[1] = (void *) fi;


    // The third argument is the return code, an output only argument, which is
    // an integer.
    arg_types[2] = (1u << ARG_OUTPUT) | (ARG_INT << 16u);
    int return_code = 0;
    args[2] = &return_code;

    // Finally, the last position of the arg types is 0. There is no
    // corresponding arg.
    arg_types[3] = 0;

    // MAKE THE RPC CALL
    int rpc_ret = rpcCall((char *)"open", arg_types, args);

    // HANDLE THE RETURN
    // The integer value watdfs_cli_mknod will return.
    int fxn_ret = 0;
    if (rpc_ret < 0) {
        DLOG("open rpc failed with error '%d'", rpc_ret);
        // Something went wrong with the rpcCall, return a sensible return
        // value. In this case lets return, -EINVAL
        fxn_ret = -EINVAL;
    } else {
        // Our RPC call succeeded. However, it's possible that the return code
        // from the server is not 0, that is it may be -errno. Therefore, we
        // should set our function return value to the retcode from the server.

        // TODO: set the function return value to the return code from the server.
        if (return_code < 0) fxn_ret = return_code;
    }
    // Clean up the memory we have allocated.
    delete []args;

    // Finally return the value we got from the server.
    return fxn_ret;
}

int watdfs_cli_release_a1(void *userdata, const char *path,
                       struct fuse_file_info *fi) {
    // Called during close, but possibly asynchronously.
    DLOG("watdfs_cli_release called for '%s'", path);
    // SET UP THE RPC CALL    
    // release has 3 arguments.
    int ARG_COUNT = 3;

    // Allocate space for the output arguments.
    void **args = new void*[ARG_COUNT];

    // Allocate the space for arg types, and one extra space for the null
    // array element.
    int arg_types[ARG_COUNT + 1];

    // The path has string length (strlen) + 1 (for the null character).
    int pathlen = strlen(path) + 1;

    // Fill in the arguments
    // The first argument is the path, it is an input only argument, and a char
    // array. The length of the array is the length of the path.
    arg_types[0] =
        (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) pathlen;
    // For arrays the argument is the array pointer, not a pointer to a pointer.
    args[0] = (void *)path;

    // The second argument is fi.
    arg_types[1] = (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) sizeof(fuse_file_info);
    args[1] = (void *) fi;


    // The third argument is the return code, an output only argument, which is
    // an integer.
    arg_types[2] = (1u << ARG_OUTPUT) | (ARG_INT << 16u);
    int return_code = 0;
    args[2] = &return_code;

    // Finally, the last position of the arg types is 0. There is no
    // corresponding arg.
    arg_types[3] = 0;

    // MAKE THE RPC CALL
    int rpc_ret = rpcCall((char *)"release", arg_types, args);

    // HANDLE THE RETURN
    // The integer value watdfs_cli_mknod will return.
    int fxn_ret = 0;
    if (rpc_ret < 0) {
        DLOG("release rpc failed with error '%d'", rpc_ret);
        // Something went wrong with the rpcCall, return a sensible return
        // value. In this case lets return, -EINVAL
        fxn_ret = -EINVAL;
    } else {
        // Our RPC call succeeded. However, it's possible that the return code
        // from the server is not 0, that is it may be -errno. Therefore, we
        // should set our function return value to the retcode from the server.

        // TODO: set the function return value to the return code from the server.
        if (return_code < 0) fxn_ret = return_code;
    }
    // Clean up the memory we have allocated.
    delete []args;

    // Finally return the value we got from the server.
    return fxn_ret;
}

// READ AND WRITE DATA
int watdfs_cli_read_a1(void *userdata, const char *path, char *buf, size_t size,
                    off_t offset, struct fuse_file_info *fi) {
    // Read size amount of data at offset of file into buf.

    // Remember that size may be greater then the maximum array size of the RPC
    // library.
    DLOG("watdfs_cli_read called for '%s'", path);
    // SET UP THE RPC CALL    
    // release has 6 arguments.
    int ARG_COUNT = 6;

    // Allocate space for the output arguments.
    void **args = new void*[ARG_COUNT];

    // Allocate the space for arg types, and one extra space for the null
    // array element.
    int arg_types[ARG_COUNT + 1];

    // The path has string length (strlen) + 1 (for the null character).
    int pathlen = strlen(path) + 1;

    // Fill in the arguments
    // The first argument is the path, it is an input only argument, and a char
    // array. The length of the array is the length of the path.
    arg_types[0] =
        (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) pathlen;
    // For arrays the argument is the array pointer, not a pointer to a pointer.
    args[0] = (void *)path;

    // // The second argument is buffer.
    // arg_types[1] = (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | size;

    // args[1] = (void *) buf;

    // The third argument is size.
    arg_types[2] = (1u << ARG_INPUT) | (ARG_LONG << 16u);
    // args[2] = (void *) &size;
    size_t sz = 0;
    args[2] = &sz;

    // The 4 argument is offset.
    arg_types[3] = (1u << ARG_INPUT) | (ARG_LONG << 16u);
    args[3] = (void *) &offset;

    arg_types[4] = (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) sizeof(fuse_file_info);
    args[4] = (void *) fi;


    // The fifth argument is the return code, an output only argument, which is
    // an integer.
    arg_types[5] = (1u << ARG_OUTPUT) | (ARG_INT << 16u);
    int return_code = 0;
    args[5] = &return_code;

    // Finally, the last position of the arg types is 0. There is no
    // corresponding arg.
    arg_types[6] = 0;


    int fxn_ret = 0;

    while (size) {
        sz = size < MAX_ARRAY_LEN ? size : MAX_ARRAY_LEN;
        size = size - sz;

        // The second argument is buffer.
        arg_types[1] = (1u << ARG_OUTPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) |(uint) sz;
        args[1] = (void *) buf;

        // MAKE THE RPC CALL
        int rpc_ret = rpcCall((char *)"read", arg_types, args);
        if (rpc_ret < 0) {
            DLOG("read rpc failed with error '%d'", rpc_ret);
            // Something went wrong with the rpcCall, return a sensible return
            // value. In this case lets return, -EINVAL
            return -EINVAL;
        } else {
            if (return_code < 0) {
            // Our RPC call succeeded. However, it's possible that the return code
            // from the server is not 0, that is it may be -errno. Therefore, we
            // should set our function return value to the retcode from the server.
            // TODO: set the function return value to the return code from the server.
            return return_code;
            }
        } 
        fxn_ret += return_code;
        offset += sz;
        buf += sz;
    }
    // Clean up the memory we have allocated.
    delete []args;

    return fxn_ret;
}
int watdfs_cli_write_a1(void *userdata, const char *path, const char *buf,
                     size_t size, off_t offset, struct fuse_file_info *fi) {
    // Write size amount of data at offset of file from buf.
    // Remember that size may be greater then the maximum array size of the RPC
    // library.
    DLOG("watdfs_cli_write called for '%s'", path);
    // SET UP THE RPC CALL    
    // write has 6 arguments.
    int ARG_COUNT = 6;

    // Allocate space for the output arguments.
    void **args = new void*[ARG_COUNT];

    // Allocate the space for arg types, and one extra space for the null
    // array element.
    int arg_types[ARG_COUNT + 1];

    // The path has string length (strlen) + 1 (for the null character).
    int pathlen = strlen(path) + 1;

    // Fill in the arguments
    // The first argument is the path, it is an input only argument, and a char
    // array. The length of the array is the length of the path.
    arg_types[0] =
        (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) pathlen;
    // For arrays the argument is the array pointer, not a pointer to a pointer.
    args[0] = (void *)path;

    // // The second argument is buffer.
    // arg_types[1] = (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | size;

    // args[1] = (void *) buf;

    // The third argument is size.
    arg_types[2] = (1u << ARG_INPUT) | (ARG_LONG << 16u);
    // args[2] = (void *) &size;
    size_t sz = 0;
    args[2] = &sz;

    // The 4 argument is offset.
    arg_types[3] = (1u << ARG_INPUT) | (ARG_LONG << 16u);
    args[3] = (void *) &offset;

    arg_types[4] = (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) sizeof(fuse_file_info);
    args[4] = (void *) fi;


    // The fifth argument is the return code, an output only argument, which is
    // an integer.
    arg_types[5] = (1u << ARG_OUTPUT) | (ARG_INT << 16u);
    int return_code = 0;
    args[5] = &return_code;

    // Finally, the last position of the arg types is 0. There is no
    // corresponding arg.
    arg_types[6] = 0;


    int fxn_ret = 0;

    while (size) {
        sz = size < MAX_ARRAY_LEN ? size : MAX_ARRAY_LEN;
        size = size - sz;

        // The second argument is buffer.
        arg_types[1] = (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) |(uint) sz;
        args[1] = (void *) buf;

        // MAKE THE RPC CALL
        int rpc_ret = rpcCall((char *)"write", arg_types, args);
        if (rpc_ret < 0) {
            DLOG("write rpc failed with error '%d'", rpc_ret);
            // Something went wrong with the rpcCall, return a sensible return
            // value. In this case lets return, -EINVAL
            return -EINVAL;
        } else {
            if (return_code < 0) {
            // Our RPC call succeeded. However, it's possible that the return code
            // from the server is not 0, that is it may be -errno. Therefore, we
            // should set our function return value to the retcode from the server.
            // TODO: set the function return value to the return code from the server.
            return return_code;
            }
        } 
        fxn_ret += return_code;
        offset += sz;
        buf += sz;
    }
    // Clean up the memory we have allocated.
    delete []args;

    return fxn_ret;
}




int watdfs_cli_truncate_a1(void *userdata, const char *path, off_t newsize) {
    // Change the file size to newsize.
    DLOG("watdfs_cli_truncate called for '%s'", path);
    // SET UP THE RPC CALL    
    // truncate has 3 arguments.
    int ARG_COUNT = 3;

    // Allocate space for the output arguments.
    void **args = new void*[ARG_COUNT];

    // Allocate the space for arg types, and one extra space for the null
    // array element.
    int arg_types[ARG_COUNT + 1];

    // The path has string length (strlen) + 1 (for the null character).
    int pathlen = strlen(path) + 1;

    // Fill in the arguments
    // The first argument is the path, it is an input only argument, and a char
    // array. The length of the array is the length of the path.
    arg_types[0] =
        (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) pathlen;
    // For arrays the argument is the array pointer, not a pointer to a pointer.
    args[0] = (void *)path;

    // The second argument is fi.
    arg_types[1] = (1u << ARG_INPUT) | (ARG_LONG << 16u);
    args[1] = &newsize;


    // The third argument is the return code, an output only argument, which is
    // an integer.
    arg_types[2] = (1u << ARG_OUTPUT) | (ARG_INT << 16u);
    int return_code = 0;
    args[2] = &return_code;

    // Finally, the last position of the arg types is 0. There is no
    // corresponding arg.
    arg_types[3] = 0;

    // MAKE THE RPC CALL
    int rpc_ret = rpcCall((char *)"truncate", arg_types, args);

    // HANDLE THE RETURN
    // The integer value watdfs_cli_mknod will return.
    int fxn_ret = 0;
    if (rpc_ret < 0) {
        DLOG("truncate rpc failed with error '%d'", rpc_ret);
        // Something went wrong with the rpcCall, return a sensible return
        // value. In this case lets return, -EINVAL
        fxn_ret = -EINVAL;
    } else {
        // Our RPC call succeeded. However, it's possible that the return code
        // from the server is not 0, that is it may be -errno. Therefore, we
        // should set our function return value to the retcode from the server.

        // TODO: set the function return value to the return code from the server.
        if (return_code < 0) fxn_ret = return_code;
    }
    // Clean up the memory we have allocated.
    delete []args;

    // Finally return the value we got from the server.
    return fxn_ret;

}


// CHANGE METADATA
int watdfs_cli_utimens_a1(void *userdata, const char *path,
                       const struct timespec ts[2]) {
    // Change file access and modification times.
        // Force a flush of file data.
    DLOG("watdfs_cli_utimens called for '%s'", path);
    // SET UP THE RPC CALL    
    // utimens has 3 arguments.
    int ARG_COUNT = 3;

    // Allocate space for the output arguments.
    void **args = new void*[ARG_COUNT];

    // Allocate the space for arg types, and one extra space for the null
    // array element.
    int arg_types[ARG_COUNT + 1];

    // The path has string length (strlen) + 1 (for the null character).
    int pathlen = strlen(path) + 1;

    // Fill in the arguments
    // The first argument is the path, it is an input only argument, and a char
    // array. The length of the array is the length of the path.
    arg_types[0] =
        (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) pathlen;
    // For arrays the argument is the array pointer, not a pointer to a pointer.
    args[0] = (void *)path;

    // The second argument is fi.
    arg_types[1] = (1u << ARG_INPUT) | (1u << ARG_ARRAY) | (ARG_CHAR << 16u) | (uint) 2 * sizeof(timespec);
    args[1] = (void *) ts;


    // The third argument is the return code, an output only argument, which is
    // an integer.
    arg_types[2] = (1u << ARG_OUTPUT) | (ARG_INT << 16u);
    int return_code = 0;
    args[2] = &return_code;

    // Finally, the last position of the arg types is 0. There is no
    // corresponding arg.
    arg_types[3] = 0;

    // MAKE THE RPC CALL
    int rpc_ret = rpcCall((char *)"utimens", arg_types, args);

    // HANDLE THE RETURN
    // The integer value watdfs_cli_mknod will return.
    int fxn_ret = 0;
    if (rpc_ret < 0) {
        DLOG("utimens rpc failed with error '%d'", rpc_ret);
        // Something went wrong with the rpcCall, return a sensible return
        // value. In this case lets return, -EINVAL
        fxn_ret = -EINVAL;
    } else {
        // Our RPC call succeeded. However, it's possible that the return code
        // from the server is not 0, that is it may be -errno. Therefore, we
        // should set our function return value to the retcode from the server.

        // TODO: set the function return value to the return code from the server.
        if (return_code < 0) fxn_ret = return_code;
    }
    // Clean up the memory we have allocated.
    delete []args;

    // Finally return the value we got from the server.
    return fxn_ret;
}

// Check the userdata if the file in the path is opened
bool user_opened_path(UserData *userdata, const char *path) {
    return userdata->file_set.count(path) != 0 ? true : false;
}

int lock(const char *path, rw_lock_mode_t mode) {
    int ARG_COUNT = 3;
    void **args = (void **) malloc(ARG_COUNT);
    int arg_types[ARG_COUNT + 1];
    int pathlen = strlen(path) + 1;
    int return_code = 0;
    arg_types[0] = (1 << ARG_INPUT) | (1 << ARG_ARRAY) | (ARG_CHAR << 16u) | pathlen;
    args[0] = (void *) path;
    arg_types[1] = (1 << ARG_INPUT) | (ARG_INT << 16u);
    args[1] = (void *) &mode;
    arg_types[2] = (1 << ARG_OUTPUT) | (ARG_INT << 16u);
    args[2] = (void *) &return_code;
    arg_types[3] = 0;
    int rpc_ret = rpcCall((char *) "lock", arg_types, args);
    int fxn_ret = rpc_ret >= 0 ? return_code : -EINVAL; 
    free(args);
    return fxn_ret;
}


int unlock(const char *path, rw_lock_mode_t mode) {
    int ARG_COUNT = 3;
    void **args = (void **) malloc(ARG_COUNT * sizeof(void *));
    int arg_types[ARG_COUNT + 1];
    int pathlen = strlen(path) + 1;
    int return_code = 0;
    arg_types[0] = (1 << ARG_INPUT) | (1 << ARG_ARRAY) | (ARG_CHAR << 16u) | pathlen;
    args[0] = (void *) path;
    arg_types[1] = (1 << ARG_INPUT) | (ARG_INT << 16u);
    args[1] = (void *) &mode;
    arg_types[2] = (1 << ARG_OUTPUT) | (ARG_INT << 16u);
    args[2] = (void *) &return_code;
    arg_types[3] = 0;
    int rpc_ret = rpcCall((char *) "unlock", arg_types, args);
    int fxn_ret = rpc_ret >= 0 ? return_code : -EINVAL; 
    free(args);
    return fxn_ret;
}


int watdfs_cli_getattr(void *userdata, const char *path, struct stat *statbuf) {
    UserData *usdt = (UserData *)userdata; 
    // get the full path
    char *fp = get_full_path(usdt->path_to_cache, path);
    int fxn_ret = 0;
    fuse_file_info fi;
    // update the file info to be read-only
    fi.flags = O_RDONLY;
    // check the file if it is currently being opened
    if (user_opened_path(usdt, path)) {
        if (usdt->file_info[path]->flags == O_RDONLY) {
            // check the file using read check
            fxn_ret = watdfs_cli_read_check(usdt, path);
            if (fxn_ret < 0) {
                free(fp);
                return fxn_ret;
            }
        }
        // retrieve the local file stat
        fxn_ret = stat(fp, statbuf);
        if (fxn_ret < 0) {
            // error happened, we have to reset the stat buffer
            memset(statbuf, 0, sizeof(struct stat));
            fxn_ret = -errno;
        }
    } else { // if the file is not opened, we open the file
        fxn_ret = watdfs_cli_open(userdata, path, &fi);
        if (fxn_ret < 0) {
            free(fp);
            return fxn_ret;
        }
        // grab the local file stat
        fxn_ret = stat(fp, statbuf);
        if (fxn_ret < 0) {
            // error happened, we have to reset the stat buffer
            memset(statbuf, 0, sizeof(struct stat));
            fxn_ret = -errno;
        }
        // release the file
        fxn_ret = watdfs_cli_release(userdata, path, &fi);
    }
    free(fp);
    return fxn_ret;
}

int watdfs_cli_mknod(void *userdata, const char *path, mode_t mode, dev_t dev) {
    UserData *usdt = (UserData *) userdata;
    char *fp = get_full_path(usdt->path_to_cache, path);
    // if the file is opened
    if (user_opened_path(usdt, path)) {
        if (usdt->file_info[path]->flags == O_RDONLY) {
            free(fp);
            return -EMFILE;
        } 
        // We want to check with write check
        int fxn_ret = watdfs_cli_write_check(usdt, path);
        free(fp);
        return fxn_ret;
    }
    struct fuse_file_info fi;
    fi.flags = O_RDWR;
    int fxn_ret = watdfs_cli_open(userdata, path, &fi);
    if (fxn_ret >= 0) {
        fxn_ret = watdfs_cli_release(userdata, path, &fi);
        if (fxn_ret >= 0) fxn_ret = -EEXIST;
    } else {
        if (fxn_ret == -EACCES) {
            free(fp);
            return fxn_ret;
        }
        fxn_ret = watdfs_cli_mknod_a1(userdata, path, mode, dev);
        if (fxn_ret < 0) {
            free(fp);
            return fxn_ret;
        }
        int sys_ret = mknod(fp, mode, dev);
        fxn_ret = sys_ret < 0 ? -EINVAL : sys_ret;
    }
    free(fp);
    return fxn_ret;
}

int watdfs_cli_open(void *userdata, const char *path, struct fuse_file_info *fi) {
    UserData *usdt = (UserData *) userdata;
    if (user_opened_path(usdt, path)) return -EMFILE;
    int f = fi->flags & O_ACCMODE;
    int fxn_ret = download(usdt, path, fi);
    if (fxn_ret < 0) return fxn_ret;
    usdt->file_set.insert(path);
    fi->flags = f;
    usdt->file_info[path]->flags = fi->flags & O_ACCMODE;
    usdt->file_info[path]->tc = time(nullptr);
    return fxn_ret;
}

int watdfs_cli_release(void *userdata, const char *path, struct fuse_file_info *fi) {
    UserData *usdt = (UserData *) userdata;
    int fxn_ret = 0;
    if ((fi->flags & O_ACCMODE) != O_RDONLY) {
        fxn_ret = upload(usdt, path, fi);
        if (fxn_ret < 0) return fxn_ret;
    }
    fxn_ret = watdfs_cli_release_a1(userdata, path, fi);
    if (fxn_ret < 0) return fxn_ret;
    int client_file_desc = usdt->file_info[path]->client_file_desc;
    fxn_ret = close(client_file_desc);
    if (fxn_ret < 0) return -errno;
    usdt->file_info.erase(path);
    usdt->file_set.erase(path);
    return fxn_ret;
}


int watdfs_cli_read(void *userdata, const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi) {
    UserData *usdt = (UserData *) userdata;
    int client_file_desc = usdt->file_info[path]->client_file_desc;
    if (usdt->file_info[path]->flags == O_RDONLY) {
        int fxn_ret = watdfs_cli_read_check(usdt, path);
        if (fxn_ret < 0) return fxn_ret;
    } else if (usdt->file_info[path]->flags == O_WRONLY) {
        return -EINVAL; 
    }
    int return_code = pread(client_file_desc, buf, size, offset);
    if (return_code < 0) return -errno;
    return return_code;
}


int watdfs_cli_write(void *userdata, const char *path, const char *buf, size_t size, off_t offset, struct fuse_file_info *fi) {
    UserData *usdt = (UserData *) userdata;
    int client_file_desc = usdt->file_info[path]->client_file_desc;
    if (usdt->file_info[path]->flags == O_RDONLY) return -EMFILE;
    int fxn_ret = watdfs_cli_write_check(usdt, path);
    if (fxn_ret < 0) return fxn_ret;
    int return_code = pwrite(client_file_desc, buf, size, offset);
    if (return_code < 0) return -errno;
    return return_code;
}


int watdfs_cli_truncate(void *userdata, const char *path, off_t newsize) {
    UserData *usdt = (UserData *) userdata;
    char *fp = get_full_path(usdt->path_to_cache, path);
    fuse_file_info fi;
    fi.flags = O_RDWR;
    if (!user_opened_path(usdt, path)) {
        // if not open we open it
        int fxn_ret = watdfs_cli_open(userdata, path, &fi);
        if (fxn_ret < 0) {
            free(fp);
            return fxn_ret;
        }
        // truncate it
        fxn_ret = truncate(fp, newsize);
        if (fxn_ret < 0) {
            free(fp);
            return -errno;
        }
        // Then release
        fxn_ret = watdfs_cli_release(userdata, path, &fi);
        free(fp);
        return fxn_ret;
    }
    // if the file is READ ONLY, we return -EMFILE
    if (usdt->file_info[path]->flags == O_RDONLY) {
        free(fp);
        return -EMFILE;

    }
    // Otherwise wee truncate the file and update it to the server
    int fxn_ret = truncate(fp, newsize);
    if (fxn_ret < 0) return -errno;
    // we have to update the writing time
    fxn_ret = watdfs_cli_write_check(usdt, path);
    free(fp);
    return fxn_ret;
}

// Just sync the file by uploading it
int watdfs_cli_fsync(void *userdata, const char *path, struct fuse_file_info *fi) {
    UserData *usdt = (UserData *) userdata;
    // sync the file
    int fxn_ret = upload(usdt, path, fi);
    if (fxn_ret < 0) return fxn_ret;
    // refresh the time
    usdt->file_info[path]->tc = time(nullptr);
    return fxn_ret;
}

int watdfs_cli_utimens(void *userdata, const char *path, const struct timespec ts[2]) {
    UserData *usdt = (UserData *) userdata;
    char *fp = get_full_path(usdt->path_to_cache, path);
    fuse_file_info fi;
    fi.flags = O_RDWR;
    int fxn_ret = 0;
    // if not open, we open it
    if (!user_opened_path(usdt, path)) {
        fxn_ret = watdfs_cli_open(userdata, path, &fi);
        if (fxn_ret < 0) {
            free(fp);
            return fxn_ret;
        }
        // update the metadata
        fxn_ret = utimensat(0, fp, ts, 0);
        if (fxn_ret < 0) {
            free(fp);
            return -errno;
        }
        // release the file
        fxn_ret = watdfs_cli_release(userdata, path, &fi);
        free(fp);
        return fxn_ret;
    }

    if (usdt->file_info[path]->flags == O_RDONLY) {
        free(fp);
        return -EMFILE;
    }
    // update the metadata
    fxn_ret = utimensat(0, fp, ts, 0);
    if (fxn_ret < 0) return -errno;
    // refresh the writing time
    fxn_ret = watdfs_cli_write_check(usdt, path);
    free(fp);
    return fxn_ret;
}

